import React from "react";
import Link from "next/link";
import { PATHS } from "@/app/_lib/data";

export const metadata = {
  title: "Learning Paths",
};

export function getPathBySlug(slug) {
  return PATHS.find((p) => p.slug === slug) ?? null;
}

export default function Paths() {
  return (
    <div className="p-6">
      <h1 className="text-4xl font-bold mb-6">Learning Paths</h1>

      <div className="block p-6 border rounded-xl shadow-sm hover:shadow-md hover:bg-gray-50 transition">
        {PATHS.slice(0, 4).map((path) => (
          <Link
            key={path.slug}
            href={`/paths/${path.slug}`}
            className="block p-4 border rounded-lg hover:bg-gray-100"
          >
            {path.name}
          </Link>
        ))}
      </div>
    </div>
  );
}