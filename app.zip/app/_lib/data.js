// ─────────────────────────────────────────────────────────────────────────────
// SkillForge · Tech Dummy Data Store
// All data is static and self-contained — no external APIs needed.
// ─────────────────────────────────────────────────────────────────────────────

export const CATEGORIES = [
  {
    slug: "web-development",
    name: "Web Development",
    icon: "◈",
    color: "#c9a84c",
    description: "Build modern, responsive web applications from the ground up.",
    courseCount: 42,
    level: "Beginner → Advanced",
  },
  {
    slug: "machine-learning",
    name: "Machine Learning",
    icon: "◉",
    color: "#7eb8f7",
    description: "Understand and implement intelligent systems using real-world data.",
    courseCount: 28,
    level: "Intermediate → Advanced",
  },
  {
    slug: "devops-cloud",
    name: "DevOps & Cloud",
    icon: "◇",
    color: "#a78bfa",
    description: "Automate, scale, and deploy software with modern cloud infrastructure.",
    courseCount: 19,
    level: "Intermediate",
  },
  {
    slug: "cybersecurity",
    name: "Cybersecurity",
    icon: "◎",
    color: "#f87171",
    description: "Protect systems, networks, and data from digital attacks.",
    courseCount: 17,
    level: "Beginner → Advanced",
  },
  {
    slug: "mobile-development",
    name: "Mobile Development",
    icon: "⊡",
    color: "#34d399",
    description: "Create polished iOS and Android apps with cross-platform frameworks.",
    courseCount: 22,
    level: "Beginner → Intermediate",
  },
  {
    slug: "system-design",
    name: "System Design",
    icon: "⊞",
    color: "#fb923c",
    description: "Architect scalable, fault-tolerant distributed systems.",
    courseCount: 14,
    level: "Advanced",
  },
  {
    slug: "databases",
    name: "Databases",
    icon: "◻",
    color: "#f0abfc",
    description: "Master relational, NoSQL, and time-series database systems.",
    courseCount: 16,
    level: "Beginner → Advanced",
  },
  {
    slug: "blockchain",
    name: "Blockchain & Web3",
    icon: "◆",
    color: "#fbbf24",
    description: "Build decentralized applications and smart contracts.",
    courseCount: 11,
    level: "Intermediate → Advanced",
  },
];

export const COURSES = [
  {
    id: 1,
    title: "Next.js 15 — The Complete Production Guide",
    slug: "nextjs-15-complete-guide",
    category: "web-development",
    instructor: "mentor-1",
    price: 89,
    originalPrice: 129,
    rating: 4.9,
    reviewCount: 2341,
    students: 18420,
    duration: "38 hours",
    level: "Intermediate",
    badge: "Bestseller",
    description:
      "Master Next.js 15 from routing and server components to ISR, edge functions, and production deployment. Build three real-world applications throughout the course.",
    tags: ["React", "Next.js", "TypeScript", "Vercel"],
    lessons: 142,
    certificate: true,
    updatedAt: "2025-03",
    modules: [
      { title: "Foundations of the App Router", lessons: 18 },
      { title: "Server & Client Components", lessons: 22 },
      { title: "Data Fetching Patterns", lessons: 16 },
      { title: "Authentication with Auth.js", lessons: 14 },
      { title: "Database Integration (Prisma + Postgres)", lessons: 20 },
      { title: "Caching, ISR & Edge Runtime", lessons: 18 },
      { title: "Testing & CI/CD", lessons: 12 },
      { title: "Deployment to Production", lessons: 22 },
    ],
  },
  {
    id: 2,
    title: "TypeScript for Engineers",
    slug: "typescript-for-engineers",
    category: "web-development",
    instructor: "mentor-2",
    price: 69,
    originalPrice: 99,
    rating: 4.8,
    reviewCount: 1876,
    students: 14200,
    duration: "24 hours",
    level: "Intermediate",
    badge: "Top Rated",
    description:
      "Go beyond the basics — generics, conditional types, template literals, the type system internals, and how to architect large TypeScript codebases that scale.",
    tags: ["TypeScript", "JavaScript", "Node.js"],
    lessons: 98,
    certificate: true,
    updatedAt: "2025-02",
    modules: [
      { title: "The Type System Deep Dive", lessons: 14 },
      { title: "Generics & Type Inference", lessons: 18 },
      { title: "Advanced Patterns", lessons: 20 },
      { title: "TypeScript in React", lessons: 16 },
      { title: "Testing Typed Code", lessons: 14 },
      { title: "Real-World Project", lessons: 16 },
    ],
  },
  {
    id: 3,
    title: "Machine Learning with Python — Zero to Production",
    slug: "ml-python-zero-to-production",
    category: "machine-learning",
    instructor: "mentor-3",
    price: 109,
    originalPrice: 159,
    rating: 4.9,
    reviewCount: 3102,
    students: 22800,
    duration: "52 hours",
    level: "Beginner → Advanced",
    badge: "New",
    description:
      "A comprehensive journey through supervised learning, neural networks, NLP, and deploying ML models at scale using FastAPI, Docker, and AWS SageMaker.",
    tags: ["Python", "scikit-learn", "PyTorch", "FastAPI", "AWS"],
    lessons: 210,
    certificate: true,
    updatedAt: "2025-03",
    modules: [
      { title: "Python for Data Science", lessons: 20 },
      { title: "Supervised Learning Fundamentals", lessons: 28 },
      { title: "Neural Networks & Deep Learning", lessons: 36 },
      { title: "NLP & Transformers", lessons: 30 },
      { title: "MLOps & Production Deployment", lessons: 26 },
      { title: "Capstone Project", lessons: 70 },
    ],
  },
  {
    id: 4,
    title: "AWS Solutions Architect — Professional",
    slug: "aws-solutions-architect-pro",
    category: "devops-cloud",
    instructor: "mentor-4",
    price: 119,
    originalPrice: 179,
    rating: 4.8,
    reviewCount: 2780,
    students: 19600,
    duration: "44 hours",
    level: "Advanced",
    badge: "Certification Prep",
    description:
      "Complete preparation for the AWS Solutions Architect Professional exam. Covers VPC design, multi-account strategies, disaster recovery, and cost optimization.",
    tags: ["AWS", "Cloud", "Infrastructure", "Terraform"],
    lessons: 176,
    certificate: true,
    updatedAt: "2025-01",
    modules: [
      { title: "AWS Core Services", lessons: 24 },
      { title: "Networking & VPCs", lessons: 22 },
      { title: "Security & Compliance", lessons: 20 },
      { title: "High Availability Architectures", lessons: 28 },
      { title: "Cost Optimization", lessons: 18 },
      { title: "Practice Exams", lessons: 64 },
    ],
  },
  {
    id: 5,
    title: "Ethical Hacking & Penetration Testing",
    slug: "ethical-hacking-pen-testing",
    category: "cybersecurity",
    instructor: "mentor-5",
    price: 94,
    originalPrice: 139,
    rating: 4.7,
    reviewCount: 1642,
    students: 12300,
    duration: "34 hours",
    level: "Intermediate",
    badge: "Hands-On",
    description:
      "Learn to think and act like an attacker. Covers reconnaissance, exploitation, privilege escalation, post-exploitation, and detailed lab environments using Kali Linux.",
    tags: ["Kali Linux", "Metasploit", "Burp Suite", "CTF"],
    lessons: 136,
    certificate: true,
    updatedAt: "2025-02",
    modules: [
      { title: "Recon & OSINT", lessons: 18 },
      { title: "Scanning & Enumeration", lessons: 20 },
      { title: "Exploitation Techniques", lessons: 28 },
      { title: "Web App Attacks", lessons: 24 },
      { title: "Post-Exploitation", lessons: 22 },
      { title: "Reporting & Remediation", lessons: 24 },
    ],
  },
  {
    id: 6,
    title: "React Native — Build iOS & Android Apps",
    slug: "react-native-ios-android",
    category: "mobile-development",
    instructor: "mentor-6",
    price: 79,
    originalPrice: 119,
    rating: 4.8,
    reviewCount: 1198,
    students: 9800,
    duration: "28 hours",
    level: "Intermediate",
    badge: "Popular",
    description:
      "From zero to app store. Build production-quality mobile apps with React Native, Expo, Reanimated, and native device integrations.",
    tags: ["React Native", "Expo", "TypeScript", "iOS", "Android"],
    lessons: 112,
    certificate: true,
    updatedAt: "2025-03",
    modules: [
      { title: "React Native Fundamentals", lessons: 20 },
      { title: "Navigation & State", lessons: 18 },
      { title: "Animations with Reanimated", lessons: 16 },
      { title: "Native Modules & APIs", lessons: 20 },
      { title: "App Store Deployment", lessons: 14 },
      { title: "Full App Build", lessons: 24 },
    ],
  },
  {
    id: 7,
    title: "System Design Interview Masterclass",
    slug: "system-design-interview-masterclass",
    category: "system-design",
    instructor: "mentor-1",
    price: 99,
    originalPrice: 149,
    rating: 4.9,
    reviewCount: 4210,
    students: 31000,
    duration: "30 hours",
    level: "Advanced",
    badge: "Interview Prep",
    description:
      "Everything you need to ace system design interviews at FAANG and top-tier tech companies. Design Twitter, YouTube, Uber, WhatsApp and 12 more real systems.",
    tags: ["System Design", "Distributed Systems", "Scalability"],
    lessons: 86,
    certificate: true,
    updatedAt: "2025-03",
    modules: [
      { title: "Design Fundamentals", lessons: 14 },
      { title: "Storage & Databases at Scale", lessons: 16 },
      { title: "Caching Strategies", lessons: 10 },
      { title: "Message Queues & Event Streaming", lessons: 12 },
      { title: "Case Studies (15 Systems)", lessons: 30 },
      { title: "Mock Interview Sessions", lessons: 4 },
    ],
  },
  {
    id: 8,
    title: "PostgreSQL Mastery",
    slug: "postgresql-mastery",
    category: "databases",
    instructor: "mentor-7",
    price: 74,
    originalPrice: 109,
    rating: 4.8,
    reviewCount: 987,
    students: 7400,
    duration: "22 hours",
    level: "Intermediate",
    badge: null,
    description:
      "Deep-dive into PostgreSQL internals, indexing strategies, query optimization, partitioning, replication, and running Postgres reliably in production.",
    tags: ["PostgreSQL", "SQL", "Database Design", "Performance"],
    lessons: 88,
    certificate: true,
    updatedAt: "2025-01",
    modules: [
      { title: "Advanced SQL", lessons: 16 },
      { title: "Indexing & Query Planning", lessons: 18 },
      { title: "Transactions & Concurrency", lessons: 14 },
      { title: "Partitioning & Sharding", lessons: 12 },
      { title: "Replication & High Availability", lessons: 14 },
      { title: "Production Tuning", lessons: 14 },
    ],
  },
  {
    id: 9,
    title: "Solidity & Smart Contract Development",
    slug: "solidity-smart-contracts",
    category: "blockchain",
    instructor: "mentor-8",
    price: 89,
    originalPrice: 129,
    rating: 4.6,
    reviewCount: 743,
    students: 5200,
    duration: "26 hours",
    level: "Intermediate",
    badge: "Web3",
    description:
      "Write, test, and deploy smart contracts on Ethereum and EVM-compatible chains. Covers DeFi patterns, NFT standards, security auditing, and Hardhat tooling.",
    tags: ["Solidity", "Ethereum", "Hardhat", "DeFi", "NFT"],
    lessons: 104,
    certificate: true,
    updatedAt: "2025-02",
    modules: [
      { title: "Solidity Fundamentals", lessons: 18 },
      { title: "ERC Standards", lessons: 16 },
      { title: "DeFi Protocol Patterns", lessons: 20 },
      { title: "Security & Auditing", lessons: 22 },
      { title: "Testing with Hardhat", lessons: 14 },
      { title: "Deployment & Verification", lessons: 14 },
    ],
  },
  {
    id: 10,
    title: "Kubernetes in Production",
    slug: "kubernetes-in-production",
    category: "devops-cloud",
    instructor: "mentor-4",
    price: 104,
    originalPrice: 149,
    rating: 4.8,
    reviewCount: 1543,
    students: 11200,
    duration: "36 hours",
    level: "Advanced",
    badge: "In-Demand",
    description:
      "Container orchestration from first principles. Deploy, scale, and operate production Kubernetes clusters on GKE, EKS, and bare metal using GitOps workflows.",
    tags: ["Kubernetes", "Docker", "Helm", "ArgoCD", "Terraform"],
    lessons: 144,
    certificate: true,
    updatedAt: "2025-02",
    modules: [
      { title: "Container Fundamentals", lessons: 16 },
      { title: "Kubernetes Core Objects", lessons: 24 },
      { title: "Networking & Ingress", lessons: 20 },
      { title: "Storage & StatefulSets", lessons: 16 },
      { title: "GitOps with ArgoCD", lessons: 22 },
      { title: "Observability & SRE", lessons: 24 },
      { title: "Security Hardening", lessons: 22 },
    ],
  },
  {
    id: 11,
    title: "LLM Engineering — Build AI-Powered Apps",
    slug: "llm-engineering-ai-apps",
    category: "machine-learning",
    instructor: "mentor-3",
    price: 129,
    originalPrice: 189,
    rating: 4.9,
    reviewCount: 2876,
    students: 24500,
    duration: "40 hours",
    level: "Intermediate → Advanced",
    badge: "Trending",
    description:
      "Build production-grade AI applications using OpenAI, Anthropic, LangChain, and LlamaIndex. Covers RAG architectures, fine-tuning, agents, and evaluation.",
    tags: ["LLMs", "Python", "LangChain", "RAG", "Agents"],
    lessons: 160,
    certificate: true,
    updatedAt: "2025-03",
    modules: [
      { title: "LLM Fundamentals", lessons: 18 },
      { title: "Prompt Engineering", lessons: 16 },
      { title: "RAG Systems", lessons: 28 },
      { title: "Building AI Agents", lessons: 30 },
      { title: "Fine-Tuning & Evaluation", lessons: 24 },
      { title: "Production AI Architecture", lessons: 44 },
    ],
  },
  {
    id: 12,
    title: "Flutter — Beautiful Cross-Platform Apps",
    slug: "flutter-cross-platform",
    category: "mobile-development",
    instructor: "mentor-6",
    price: 69,
    originalPrice: 99,
    rating: 4.7,
    reviewCount: 892,
    students: 7100,
    duration: "24 hours",
    level: "Beginner → Intermediate",
    badge: null,
    description:
      "Build stunning iOS, Android, and web apps from a single Dart codebase. Covers widgets, state management (Riverpod), Firebase integration, and animations.",
    tags: ["Flutter", "Dart", "Firebase", "Riverpod"],
    lessons: 96,
    certificate: true,
    updatedAt: "2025-01",
    modules: [
      { title: "Dart & Flutter Basics", lessons: 18 },
      { title: "Widgets & Layouts", lessons: 20 },
      { title: "State Management", lessons: 16 },
      { title: "Firebase Backend", lessons: 18 },
      { title: "Animations", lessons: 12 },
      { title: "Full App Project", lessons: 12 },
    ],
  },
];

export const MENTORS = [
  {
    id: "mentor-1",
    name: "Arjun Mehta",
    role: "Principal Engineer, ex-Vercel",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Arjun&backgroundColor=b6e3f4",
    location: "San Francisco, CA",
    courses: [1, 7],
    rating: 4.9,
    students: 49420,
    bio: "10 years building large-scale React applications. Led the developer experience team at Vercel. Author of 'Patterns for Production React'.",
    skills: ["React", "Next.js", "System Design", "TypeScript"],
    github: "github.com/arjunmehta",
    twitter: "@arjunbuilds",
  },
  {
    id: "mentor-2",
    name: "Sofia Lindqvist",
    role: "Staff Engineer, TypeScript Core Contributor",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Sofia&backgroundColor=c0aede",
    location: "Stockholm, Sweden",
    courses: [2],
    rating: 4.8,
    students: 14200,
    bio: "TypeScript core contributor with 8 years in the language. Previously at Stripe and Microsoft. Passionate about type-safe architecture at scale.",
    skills: ["TypeScript", "JavaScript", "Compiler Design", "Node.js"],
    github: "github.com/sofialindqvist",
    twitter: "@sofiatypes",
  },
  {
    id: "mentor-3",
    name: "Dr. Priya Nair",
    role: "ML Research Lead, ex-Google Brain",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Priya&backgroundColor=d1d4f9",
    location: "London, UK",
    courses: [3, 11],
    rating: 4.9,
    students: 47300,
    bio: "PhD in Machine Learning from MIT. Five years at Google Brain working on transformer architectures. Published 12 papers in top-tier ML conferences.",
    skills: ["Python", "PyTorch", "LLMs", "MLOps", "Research"],
    github: "github.com/priyanair",
    twitter: "@priya_ml",
  },
  {
    id: "mentor-4",
    name: "Marcus Webb",
    role: "Platform Architect, ex-Netflix",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Marcus&backgroundColor=ffdfbf",
    location: "Austin, TX",
    courses: [4, 10],
    rating: 4.8,
    students: 30800,
    bio: "Spent 7 years at Netflix building the edge delivery infrastructure. AWS Community Hero. Believes cloud architecture is the defining skill of the decade.",
    skills: ["AWS", "Kubernetes", "Terraform", "System Reliability"],
    github: "github.com/marcuswebb",
    twitter: "@marcuscloud",
  },
  {
    id: "mentor-5",
    name: "Leila Karimi",
    role: "Offensive Security Lead, ex-NSA Red Team",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Leila&backgroundColor=ffd5dc",
    location: "Washington, D.C.",
    courses: [5],
    rating: 4.7,
    students: 12300,
    bio: "OSCP, CEH, CISSP certified. Former NSA red team operator. Now runs her own security consultancy helping Fortune 500 companies harden their attack surface.",
    skills: ["Penetration Testing", "OSINT", "Malware Analysis", "Incident Response"],
    github: "github.com/leilakarimi",
    twitter: "@leilaoscp",
  },
  {
    id: "mentor-6",
    name: "Kai Okafor",
    role: "Mobile Engineering Lead",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Kai&backgroundColor=c7f2a4",
    location: "Lagos, Nigeria",
    courses: [6, 12],
    rating: 4.8,
    students: 16900,
    bio: "Built mobile apps with over 2M combined downloads. Previously led mobile at Paystack. Conference speaker at React Native EU and Flutter Forward.",
    skills: ["React Native", "Flutter", "Swift", "Kotlin", "Expo"],
    github: "github.com/kaiokafor",
    twitter: "@kaimobile",
  },
  {
    id: "mentor-7",
    name: "Hannah Schreiber",
    role: "Database Architect, PostgreSQL Expert",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Hannah&backgroundColor=f9c6d0",
    location: "Berlin, Germany",
    courses: [8],
    rating: 4.8,
    students: 7400,
    bio: "Decade of experience designing high-performance database systems for fintech. Contributor to the PostgreSQL project. Writes the 'Query Planner' newsletter.",
    skills: ["PostgreSQL", "SQL", "Redis", "ClickHouse", "Performance Tuning"],
    github: "github.com/hannahdb",
    twitter: "@hannahpostgres",
  },
  {
    id: "mentor-8",
    name: "Ryu Tanaka",
    role: "Web3 Protocol Engineer",
    avatar: "https://api.dicebear.com/8.x/notionists/svg?seed=Ryu&backgroundColor=b6e3f4",
    location: "Tokyo, Japan",
    courses: [9],
    rating: 4.6,
    students: 5200,
    bio: "Solidity developer since 2017. Audited protocols securing over $4B TVL. Co-author of the ERC-4337 account abstraction reference implementation.",
    skills: ["Solidity", "Ethereum", "DeFi", "Security Auditing", "Hardhat"],
    github: "github.com/ryutanaka",
    twitter: "@ryudefi",
  },
];

export const PATHS = [
  {
    slug: "frontend-engineer",
    title: "Frontend Engineer",
    tagline: "From fundamentals to production-grade React applications",
    icon: "◈",
    color: "#c9a84c",
    duration: "6 months",
    level: "Beginner → Senior",
    courses: [1, 2],
    outcomes: [
      "Build full-stack Next.js applications",
      "Write robust TypeScript at scale",
      "Master state management and performance optimization",
      "Deploy to production with CI/CD pipelines",
    ],
    steps: [
      { phase: "Foundation", courses: [2], weeks: 4, desc: "TypeScript and modern JavaScript patterns" },
      { phase: "Core Skills", courses: [1], weeks: 8, desc: "Next.js App Router, SSR, and data fetching" },
      { phase: "Specialization", courses: [7], weeks: 6, desc: "System thinking for frontend architecture" },
    ],
  },
  {
    slug: "ai-ml-engineer",
    title: "AI / ML Engineer",
    tagline: "Build intelligent systems from data to deployment",
    icon: "◉",
    color: "#7eb8f7",
    duration: "9 months",
    level: "Intermediate → Expert",
    courses: [3, 11],
    outcomes: [
      "Train and evaluate machine learning models",
      "Build RAG-powered LLM applications",
      "Deploy ML systems to production at scale",
      "Design agentic AI workflows",
    ],
    steps: [
      { phase: "ML Foundations", courses: [3], weeks: 10, desc: "Python, data science, and classical ML" },
      { phase: "Deep Learning", courses: [3], weeks: 8, desc: "Neural networks, NLP, and transformers" },
      { phase: "LLM Engineering", courses: [11], weeks: 10, desc: "Production AI apps and agentic systems" },
    ],
  },
  {
    slug: "cloud-devops",
    title: "Cloud & DevOps Engineer",
    tagline: "Automate, scale, and operate modern infrastructure",
    icon: "◇",
    color: "#a78bfa",
    duration: "7 months",
    level: "Intermediate → Senior",
    courses: [4, 10],
    outcomes: [
      "Architect multi-region AWS infrastructure",
      "Operate production Kubernetes clusters",
      "Implement GitOps and CI/CD pipelines",
      "Design for reliability and cost efficiency",
    ],
    steps: [
      { phase: "Cloud Foundations", courses: [4], weeks: 8, desc: "AWS architecture and certification prep" },
      { phase: "Containers & Orchestration", courses: [10], weeks: 10, desc: "Docker and production Kubernetes" },
      { phase: "SRE Practices", courses: [10], weeks: 6, desc: "Observability, SLOs, and incident management" },
    ],
  },
  {
    slug: "security-engineer",
    title: "Security Engineer",
    tagline: "Protect systems by learning to break them",
    icon: "◎",
    color: "#f87171",
    duration: "5 months",
    level: "Intermediate → Advanced",
    courses: [5],
    outcomes: [
      "Conduct professional penetration tests",
      "Identify and exploit common vulnerabilities",
      "Write detailed security assessment reports",
      "Prepare for OSCP certification",
    ],
    steps: [
      { phase: "Recon & Network", courses: [5], weeks: 6, desc: "OSINT, scanning, and network exploitation" },
      { phase: "Web & Application", courses: [5], weeks: 8, desc: "OWASP Top 10 and web attack techniques" },
      { phase: "Advanced Exploitation", courses: [5], weeks: 6, desc: "Post-exploitation and report writing" },
    ],
  },
];

export const BLOG_POSTS = [
  {
    id: 1,
    title: "React Server Components Are Changing Everything",
    slug: "react-server-components-changing-everything",
    category: "web-development",
    author: "mentor-1",
    date: "2025-03-01",
    readTime: "8 min",
    tags: ["React", "Next.js", "Performance"],
    excerpt:
      "After a year of building production apps with RSC, here's an honest breakdown of where they shine, where they hurt, and the mental model that finally made everything click.",
    body: `React Server Components fundamentally change how we think about the boundary between server and client. For most of the past decade, we've been shipping JavaScript to the browser that fetches data, renders UI, and handles interactions — all in the same bundle.

RSC breaks this assumption. Components that don't need interactivity never ship to the client at all. They render once on the server, and only the final HTML (plus a serialized component tree) reaches the browser. The result? Smaller bundles, faster time-to-interactive, and data fetching that lives right next to the components that need it.

The mental model that unlocked it for me: think of your app as two separate worlds. The server world is async, has direct database access, and never re-renders. The client world is interactive, has state and effects, and cares deeply about bundle size. Your job as an architect is to draw the right boundary between them.

Where RSC shines: dashboards with lots of data-driven UI, marketing pages that need SEO, any component tree that's mostly static with small interactive islands.

Where it creates friction: deeply interactive features (rich text editors, drag-and-drop, real-time UI), third-party libraries that assume a browser environment, and teams still building the intuition for the mental model.

The key insight: RSC isn't a replacement for client components — it's a composition model. The best Next.js apps I've seen treat RSC as the default, reach for 'use client' deliberately, and design their data layer around async server components that can stream.`,
    views: 18420,
    reactions: { likes: 892, saves: 341 },
  },
  {
    id: 2,
    title: "The LLM Stack in 2025: What's Actually Worth Learning",
    slug: "llm-stack-2025-whats-worth-learning",
    category: "machine-learning",
    author: "mentor-3",
    date: "2025-02-22",
    readTime: "12 min",
    tags: ["LLMs", "AI Engineering", "Career"],
    excerpt:
      "The tooling around large language models has matured dramatically. Here's how I'd structure your learning if you're entering the field today — and what to ignore.",
    body: `The AI engineering landscape moves fast enough that advice from six months ago is often obsolete. But after two years in production LLM systems, some patterns have proven durable.

Start with the fundamentals of how transformers work. You don't need to implement one from scratch, but understanding attention mechanisms, context windows, and token probabilities gives you an intuition that makes everything downstream click. Andrej Karpathy's materials are still the best starting point here.

Learn prompt engineering as a discipline. It's not just 'write better prompts' — it's understanding few-shot learning, chain-of-thought reasoning, structured outputs, and how different models respond to different framing. This skill transfers across every model you'll ever use.

RAG (Retrieval Augmented Generation) is now table stakes. Almost every production LLM app has some form of it. Learn vector databases (pgvector is underrated), embedding models, chunking strategies, and how to evaluate retrieval quality. Bad RAG is worse than no RAG.

Agents are powerful and fragile. The tooling (LangGraph, CrewAI, AutoGen) has stabilized, but agents require a different reliability mindset. They fail in unexpected ways. Learn to design tight feedback loops, use structured outputs religiously, and build eval pipelines before your agents touch production.

What to deprioritize: framework-specific APIs that change constantly, fine-tuning until you've exhausted prompting and RAG, and building your own model infrastructure (unless you're at a lab).

The engineers who will matter most in the next few years are those who can design reliable systems around unreliable components. That's the real skill.`,
    views: 24800,
    reactions: { likes: 1240, saves: 680 },
  },
  {
    id: 3,
    title: "Kubernetes Isn't the Hard Part. Operations Is.",
    slug: "kubernetes-operations-is-the-hard-part",
    category: "devops-cloud",
    author: "mentor-4",
    date: "2025-02-14",
    readTime: "10 min",
    tags: ["Kubernetes", "SRE", "DevOps"],
    excerpt:
      "After running Kubernetes in production for Netflix and three startups, I've concluded that the API is the easy part. Here's what nobody tells you about day-two operations.",
    body: `Getting Kubernetes running takes a weekend. Running it reliably for years takes a fundamentally different mindset.

The tutorial gap is real. Every Kubernetes course teaches you deployments, services, and ingresses. Almost none of them teach you what happens at 3am when a node drains unexpectedly, your StatefulSets won't reschedule, and your PVCs are stuck in a terminating state.

Here's what I've learned from running production clusters at scale:

Observability is not optional. You need metrics (Prometheus + Grafana), structured logs (Loki or OpenSearch), and distributed traces (Tempo or Jaeger) from day one. The clusters that go dark are always the ones that weren't instrumented. Define your SLOs before you write your first deployment manifest.

Resource management is subtle. Setting proper requests and limits feels tedious until your cluster starts evicting pods at 2am because someone deployed a service with no limits. Use LimitRanges as cluster-wide guardrails. Profile your actual resource usage before setting targets.

Network policies are not enforced by default. Many teams run Kubernetes for years with zero network segmentation, then discover this when they're writing their incident report. Enable a CNI plugin that supports NetworkPolicy (Calico, Cilium) and implement least-privilege networking from the start.

Upgrade strategy matters more than people realize. Plan for cluster upgrades every 3-4 months to stay on supported versions. Blue-green cluster upgrades (running two clusters and migrating workloads) are more work upfront but far safer than in-place upgrades for critical infrastructure.

The teams that operate Kubernetes well treat it like a distributed database: they plan for failure, instrument everything, and never assume a component will stay healthy indefinitely.`,
    views: 14200,
    reactions: { likes: 743, saves: 298 },
  },
  {
    id: 4,
    title: "How I Passed OSCP on My First Attempt",
    slug: "how-i-passed-oscp-first-attempt",
    category: "cybersecurity",
    author: "mentor-5",
    date: "2025-01-30",
    readTime: "15 min",
    tags: ["OSCP", "Cybersecurity", "Career", "Certification"],
    excerpt:
      "The OSCP is one of the most respected certifications in offensive security. Here's the exact preparation strategy, resources, and mindset that got me through the 24-hour exam.",
    body: `The OSCP (Offensive Security Certified Professional) isn't like other certifications. There's no multiple choice. You get 24 hours to compromise a network of machines and another 24 hours to write your report. It tests not just knowledge, but persistence, methodology, and the ability to think under pressure.

Here's what actually worked for my preparation:

Build the enumeration habit first. Most beginners skip enumeration because it feels slow. This is fatal in the exam. Spend a month just running nmap, gobuster, enum4linux, and reading their output carefully. The vulnerability is almost always in what you find during recon — not in some exotic exploit.

Master the fundamentals before tools. Understand why a buffer overflow works before running exploit-db scripts. Understand how Active Directory authentication works before running BloodHound. Tools change; fundamentals don't. The exam will put you in situations where tools fail and you need to reason from first principles.

Do every machine in the PEN-200 labs. All of them. The lab environment is closer to the exam than any third-party practice platform. When you've rooted 50+ machines in the lab, the exam machines feel familiar even when they're new.

Keep a methodology document. Every time you solve a machine, add it to your personal methodology. What did you enumerate? What vector did you find? How did you escalate? After 60 machines, you'll have a personalized playbook that covers most situations.

The exam mindset: when you're stuck, go wider before going deeper. Try a different machine. Come back with fresh eyes. Most people who fail the exam did so because they rabbit-holed on one approach instead of pivoting.

The report matters as much as the shells. Start a draft during the exam. Document every step with screenshots. A great report on a machine you partially compromised is worth more than a poorly documented root shell.`,
    views: 31600,
    reactions: { likes: 1876, saves: 924 },
  },
  {
    id: 5,
    title: "PostgreSQL Query Optimization: A Practical Guide",
    slug: "postgresql-query-optimization-practical-guide",
    category: "databases",
    author: "mentor-7",
    date: "2025-01-18",
    readTime: "11 min",
    tags: ["PostgreSQL", "Performance", "SQL", "Databases"],
    excerpt:
      "Slow queries are almost always a solved problem — if you know how to read the query planner. Here's the systematic approach I use to turn 10-second queries into millisecond ones.",
    body: `Every application will eventually have a query that's too slow. The difference between engineers who solve this quickly and those who guess their way through it is knowing how to read PostgreSQL's EXPLAIN output.

Start with EXPLAIN (ANALYZE, BUFFERS). Not just EXPLAIN — always ANALYZE (which actually runs the query) and BUFFERS (which shows cache behavior). The output tells you exactly what the query planner decided to do and how long each step actually took.

The three numbers that matter most: actual rows vs. estimated rows (large gaps indicate stale statistics), actual time (which steps are expensive), and buffers hit vs. read (cache misses are expensive).

Sequential scans aren't always bad. A sequential scan on a small table is often faster than an index scan. The planner knows this. If you see a sequential scan on a 100M row table for a selective query, that's a problem — but context matters enormously.

Index strategy is not 'add an index on every column'. Understand what queries you're running, then build indexes for them. Partial indexes (WHERE clause on the index) can be dramatically more efficient for filtered queries. Covering indexes (INCLUDE columns) eliminate table lookups entirely for the right queries.

Statistics matter more than most engineers realize. Run ANALYZE after large data loads. Increase the statistics target (ALTER TABLE ... ALTER COLUMN ... SET STATISTICS) for columns with non-uniform distributions that are used in WHERE clauses.

The most impactful optimizations I've made in production: fixing N+1 queries by moving logic to SQL, adding partial indexes on status/state columns for soft-delete patterns, and replacing correlated subqueries with window functions.

Never optimize blindly. Measure first, understand the plan, form a hypothesis, test. A methodical approach beats intuition every time.`,
    views: 11400,
    reactions: { likes: 612, saves: 387 },
  },
];

// ─── Helper functions ──────────────────────────────────────────────────────

export function getCourseById(id) {
  return COURSES.find((c) => c.id === Number(id)) ?? null;
}

export function getMentorById(id) {
  return MENTORS.find((m) => m.id === id) ?? null;
}

export function getCategoryBySlug(slug) {
  return CATEGORIES.find((c) => c.slug === slug) ?? null;
}

export function getPathBySlug(slug) {
  return PATHS.find((p) => p.slug === slug) ?? null;
}

export function getBlogById(id) {
  return BLOG_POSTS.find((p) => p.id === Number(id)) ?? null;
}

export function getCoursesByCategory(slug) {
  return COURSES.filter((c) => c.category === slug);
}

export function getMentorForCourse(courseId) {
  const course = getCourseById(courseId);
  if (!course) return null;
  return getMentorById(course.instructor);
}
